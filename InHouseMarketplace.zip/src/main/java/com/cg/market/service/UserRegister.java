package com.cg.market.service;

import com.cg.market.dto.UserDetails;

public interface UserRegister {

	UserDetails register(UserDetails uDetails);

}
