package com.cg.market.exception;

public class ProposalNotFoundException extends RuntimeException {

	public ProposalNotFoundException(String msg) {
		super(msg);

	}

}
