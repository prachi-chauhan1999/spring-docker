package com.cg.market.exception;

public class OfferAlreadyExistsException extends RuntimeException {

	public OfferAlreadyExistsException(String msg) {
		super(msg);
	}

}
