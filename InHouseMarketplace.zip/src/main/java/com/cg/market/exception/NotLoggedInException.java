package com.cg.market.exception;

public class NotLoggedInException extends RuntimeException {

	public NotLoggedInException(String msg) {
		super(msg);
	}

}
