package com.cg.market.exception;

public class RequirementAlreadyExistsException extends RuntimeException {

	public RequirementAlreadyExistsException(String msg) {
		super(msg);

	}

}
