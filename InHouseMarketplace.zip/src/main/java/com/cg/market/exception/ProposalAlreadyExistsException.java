package com.cg.market.exception;

public class ProposalAlreadyExistsException extends RuntimeException {

	public ProposalAlreadyExistsException(String msg) {
		super(msg);
	}

}
