package com.cg.market.exception;

public class InvalidPasswordException extends RuntimeException {

	public InvalidPasswordException(String msg) {
		super(msg);
	}

}
