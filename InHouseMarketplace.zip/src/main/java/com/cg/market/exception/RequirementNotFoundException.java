package com.cg.market.exception;

public class RequirementNotFoundException extends RuntimeException {

	public RequirementNotFoundException(String msg) {
		super(msg);
	}

}
