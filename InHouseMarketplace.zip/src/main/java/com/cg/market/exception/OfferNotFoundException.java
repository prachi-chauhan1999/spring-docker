package com.cg.market.exception;

public class OfferNotFoundException extends RuntimeException {

	public OfferNotFoundException(String msg) {
		super(msg);

	}

}
